# Nova Moderation Bot
Hi, this is Nova, the Oficial Modertion Bot of BroCode Community.

## Features
- Profanity Filter
Filters Profanity in English only for now.

- NSFW Filter
Filters any NSFW Photo in the group.

- Commands
```
;h or ;help - For all Commands and Help
;wikipedia - for Wiki Search
;source - for Source Code
;web - For Other links
;oof - Random Insults
;gpt - GPT 3.5 Turbo Integration
;wikipedia - Get wikipedia articles
;0x0-img - Upload the Attached image to https://0x0.st
;weather - Get Weather of Any place you desire
```

## Installation
Either, send a group invite to '+919091237515' or Host is yourself and login via any of your Whatsapp Accounts.
Don't worry Tutorial comming soon.

## Contributions
Contributions are welcome. https://brocode-tech.netlify.app/ Visit for the Group Links.
